#include <iostream>
using namespace std;

template <typename Elem> struct Node {
    Elem elem;
    Node* prev;
    Node* next;
};

// Forward declaration of NodeList so that it can be used in Iterator's friend declaration
template <typename Elem> class NodeList;

template <typename Elem>
class Iterator {
private:
    Node<Elem>* v;
    Iterator(Node<Elem>* u); // Constructor is private

public:
    Elem& operator*();
    bool operator==(const Iterator& p) const;
    bool operator!=(const Iterator& p) const;
    Iterator& operator++();
    Iterator& operator--();

    // Declare NodeList as a friend so it can access private members of Iterator
    friend class NodeList<Elem>;
};

// Definition of Iterator class methods
template <typename Elem>
Iterator<Elem>::Iterator(Node<Elem>* u) {
    v = u;
}

template <typename Elem>
Elem& Iterator<Elem>::operator*() {
    return v->elem;
}

template <typename Elem>
bool Iterator<Elem>::operator==(const Iterator& p) const {
    return v == p.v;
}

template <typename Elem>
bool Iterator<Elem>::operator!=(const Iterator& p) const {
    return v != p.v;
}

template <typename Elem>
Iterator<Elem>& Iterator<Elem>::operator++() {
    v = v->next;
    return *this;
}

template <typename Elem>
Iterator<Elem>& Iterator<Elem>::operator--() {
    v = v->prev;
    return *this;
}

// Definition of NodeList class
template <typename Elem>
class NodeList {
private:
    int n;
    Node<Elem>* header;
    Node<Elem>* trailer;

public:
    NodeList();
    ~NodeList(); // Destructor to clean up memory
    int size() const;
    bool empty() const;
    Iterator<Elem> begin() const;
    Iterator<Elem> end() const;
    void insertFront(const Elem& e);
    void insertBack(const Elem& e);
    void insert(const Iterator<Elem>& p, const Elem& e);
    void eraseFront();
    void eraseBack();
    void erase(const Iterator<Elem>& p);
};

// Definition of NodeList class methods
template <typename Elem>
NodeList<Elem>::NodeList() {
    n = 0;
    header = new Node<Elem>;
    trailer = new Node<Elem>;
    header->next = trailer;
    trailer->prev = header;
}

template <typename Elem>
NodeList<Elem>::~NodeList() {
    while (!empty()) eraseFront();
    delete header;
    delete trailer;
}

template <typename Elem>
int NodeList<Elem>::size() const {
    return n;
}

template <typename Elem>
bool NodeList<Elem>::empty() const {
    return (n == 0);
}

template <typename Elem>
Iterator<Elem> NodeList<Elem>::begin() const {
    return Iterator<Elem>(header->next);
}

template <typename Elem>
Iterator<Elem> NodeList<Elem>::end() const {
    return Iterator<Elem>(trailer);
}

// Insert a new node before the node referenced by iterator p
template <typename Elem>
void NodeList<Elem>::insert(const Iterator<Elem>& p, const Elem& e) {
    Node<Elem>* w = p.v;
    Node<Elem>* u = w->prev;
    Node<Elem>* v = new Node<Elem>;
    v->elem = e;
    v->next = w;
    w->prev = v;
    v->prev = u;
    u->next = v;
    n++;
}

template <typename Elem>
void NodeList<Elem>::insertFront(const Elem& e) {
    insert(begin(), e);
}

template <typename Elem>
void NodeList<Elem>::insertBack(const Elem& e) {
    insert(end(), e);
}

template <typename Elem>
void NodeList<Elem>::erase(const Iterator<Elem>& p) {
    Node<Elem>* v = p.v;
    Node<Elem>* w = v->next;
    Node<Elem>* u = v->prev;
    u->next = w;
    w->prev = u;
    delete v;
    n--;
}

template <typename Elem>
void NodeList<Elem>::eraseFront() {
    erase(begin());
}

template <typename Elem>
void NodeList<Elem>::eraseBack() {
    erase(--end());
}

// Utility function to print the menu
void print_menu() {
    cout << "\n================= MENU =================\n";
    cout << "1. Insert element at the front\n";
    cout << "2. Insert element at the back\n";
    cout << "3. Erase element from the front\n";
    cout << "4. Erase element from the back\n";
    cout << "5. Display list\n";
    cout << "6. Display list size\n";
    cout << "7. Exit\n";
    cout << "========================================\n";
}

// Utility function to display the elements in the list
template <typename Elem>
void display_list(const NodeList<Elem>& list) {
    cout << "List: ";
    for (Iterator<Elem> it = list.begin(); it != list.end(); ++it) {
        cout << *it << " ";
    }
    cout << endl;
}

// Main function to demonstrate the NodeList
int main() {
    NodeList<int> list;
    int choice, elem;

    do {
        print_menu();
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter the element to insert at the front: ";
                cin >> elem;
                list.insertFront(elem);
                cout << "Element inserted at the front.\n";
                break;

            case 2:
                cout << "Enter the element to insert at the back: ";
                cin >> elem;
                list.insertBack(elem);
                cout << "Element inserted at the back.\n";
                break;

            case 3:
                if (!list.empty()) {
                    list.eraseFront();
                    cout << "Element erased from the front.\n";
                } else {
                    cout << "The list is empty!\n";
                }
                break;

            case 4:
                if (!list.empty()) {
                    list.eraseBack();
                    cout << "Element erased from the back.\n";
                } else {
                    cout << "The list is empty!\n";
                }
                break;

            case 5:
                if (!list.empty()) {
                    display_list(list);
                } else {
                    cout << "The list is empty!\n";
                }
                break;

            case 6:
                cout << "The list contains " << list.size() << " elements.\n";
                break;

            case 7:
                cout << "Exiting...\n";
                break;

            default:
                cout << "Invalid choice! Please try again.\n";
        }

    } while (choice != 7);

    return 0;
}


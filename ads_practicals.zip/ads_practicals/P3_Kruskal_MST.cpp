#include <iostream>
#include <climits>
using namespace std;

class Graph{
	int n; //total number of nodes
	int e; //total number of edges
	
	int * startNode;
	int * endNode;
	int * weight;
	int * parent;
	int * includeEdge;
	
	public:
		
		//constructor
		Graph(int node, int edges){
			n = node;
			e = edges;
			startNode = new int[e];
			endNode = new int[e];
			weight = new int[e];
			parent = new int[n];
			for(int i=0; i<n; i++){
				parent[i] = i;
			}
			
			includeEdge = new int[e];
			for(int i=0; i<e; i++){
				includeEdge[i] = 0;
			}
		}
		
		//Destructor
		~Graph(){
			delete[] startNode;
			delete[] endNode;
			delete[] weight;
			delete[] parent;
			delete[] includeEdge;
		}
		
		void sort(){
			// Insertion sort
			for(int i=0; i<e; i++){
				int temp1 = weight[i];
				int temp2 = startNode[i];
				int temp3 = endNode[i];
				int j = i-1;
				while(j >= 0 && weight[j] > temp1){
					weight[j+1] = weight[j];
					startNode[j+1] = startNode[j];
					endNode[j+1] = endNode[j];
					j--;
				}
				weight[j+1] = temp1;
				startNode[j+1] = temp2;
				endNode[j+1] = temp3;
			}
		}
		
		//setter
		void input(){
			int snd, end, wt;
			for(int i = 0; i < e; i++){
				cout << "\nEnter starting node: ";
				cin >> snd;
				if(snd < 1 || snd > n){
					cout << "\nError: Node must be from 1 to " << n << endl;
					i--;
					continue;
				}
				
				cout << "Enter destination node: ";
				cin >> end;
				if(end < 1 || end > n){
					cout << "\nError: Node must be from 1 to " << n << endl;
					i--;
					continue;
				}
				
				cout << "Enter weight of edge: ";
				cin >> wt;
				
				// Adjust to zero-based index
				startNode[i] = snd - 1;
				endNode[i] = end - 1;
				weight[i] = wt;
			}
			
			sort();  // Sort edges based on their weights
		}
		
		int find(int i){
			if(i == parent[i]){
				return i;
			}else{
				return (parent[i] = find(parent[i]));  // Path compression
			}
		}
		
		void display(){
			cout << "\nMINIMUM SPANNING TREE\nStartNode \t EndNode \t Weight\n";
			for(int i=0; i<e; i++){
				if(includeEdge[i] == 1){
					int u = startNode[i] + 1;  // Convert to one-based index for display
					int v = endNode[i] + 1;    // Convert to one-based index for display
					int w = weight[i];
					cout << u << " \t\t " << v << " \t\t " << w << endl;
				}
			}
		}
		
		void kruskal(){
			int edgeCount = 0;
			int total_weight = 0;
			for(int i = 0; i < e && edgeCount < n-1; i++){
				int u = startNode[i];
				int v = endNode[i];
				int w = weight[i];
				
				int root_u = find(u);
				int root_v = find(v);
				
				if(root_u != root_v){  // Check if they are in different sets
					parent[root_v] = root_u;  // Union the sets
					includeEdge[i] = 1;
					edgeCount++;
					total_weight += w;  // Add the weight of the selected edge
				}
			}
			
			if(edgeCount != n-1){
				cout << "\nError: The entered graph is not connected.\n";
			}else{
				cout << "\nTotal weight of the Minimum Spanning Tree: " << total_weight << endl;
				display();
			}
		}
};

int main(){
	int n, e;
	do{
		cout << "\nEnter the total number of nodes: ";
		cin >> n;
		if(n < 1){
			cout << "\nError: Total number of nodes can't be less than 1.\n";
		}
	} while(n < 1);
	
	do{
		cout << "\nEnter the total number of edges: ";
		cin >> e;
		if(e < 0){
			cout << "\nError: Total number of edges can't be less than 0.\n";
		}
	} while(e < 0);
	
	Graph g(n, e);
	g.input();
	g.kruskal();
	return 0;
}


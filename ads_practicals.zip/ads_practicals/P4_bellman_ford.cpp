#include <iostream>
#include <climits>
using namespace std;

class Graph{
	private:
		int n, e;
		int *startnode, *endnode, *weight;
		//the above dynamic arrays will have the same length = e (number of edges)
		
	public:
		Graph(int nodes, int edges){
			n = nodes;
			e = edges;
			
			startnode = new int[e];
			endnode = new int[e];
			weight = new int[e];
		}
		
		~Graph(){
			delete[] startnode;
			delete[] endnode;
			delete[] weight;
		}
		
		void input(){
			int s_node, e_node, wt;
			for(int i=0; i<e; i++){
				cout << "\nEnter starting node of edge " << i+1 << " : ";
				cin >> s_node;
				if(s_node<1 || s_node>n){
					cout<<"\nError : Node must be from 1 to "<<n<<endl;
					i--;
					continue;
				}
				
				cout << "Enter terminating node of edge " << i+1 << " : ";
				cin >> e_node;
				if(e_node<1 || e_node>n){
					cout<<"\nError : Node must be from 1 to "<<n<<endl;
					i--;
					continue;
				}
				
				cout << "Enter weight of the edge: ";
				cin >> wt;
				
				startnode[i] = s_node;
				endnode[i] = e_node;
				weight[i] = wt;
			}
			return;
		}
		
		void minimum_distance(){
			int srcnd;
			
			cout<<"\n\nFINDING THE MINIMUM DISTANCE\n";
			do{
				cout<<"\nEnter the source node : ";
				cin>>srcnd;
				if(srcnd < 1 || srcnd >n){
					cout<<"\nError : Node must be from 1 to "<<n<<endl;
				}
			}while(srcnd < 1 || srcnd > n);
			
			int dist[n+1];
			for(int i=0; i<=n; i++){
				dist[i] = INT_MAX;
			}
			
			dist[srcnd] = 0;
			
			//n-1 edges
			for(int i=1; i<=n-1; i++){
				for(int j=0; j<e; j++){
					int u = startnode[j];
					int v = endnode[j];
					int w = weight[j];
					
					if(dist[u]!=INT_MAX && dist[v] > dist[u]+w){
						dist[v] = dist[u]+w;
					}
				}
			}
			
			//checking the negative cycle
			//if there still exists a minimum distance after n-1 loop, there is a negative cycle
			bool negCycle = 0;
			for(int j = 0; j<e; j++){
					int u = startnode[j];
					int v = endnode[j];
					int w = weight[j];
					
					if(dist[u]!=INT_MAX && dist[v] > dist[u] + w){
						negCycle = 1;
					}
			}
			
			if(negCycle){
				cout<<"\nNegative cycle exist in the graph";
			}else{
				cout<<"\nMinimum distance of each node from source node "<<srcnd<<endl;
				cout<<"Node \t distance\n";
				for(int i = 1; i<=n; i++){
					if(dist[i]==INT_MAX){
						cout<<i<<"    :    Not reachable (inf)"<<endl;
					}else{
						cout<<i<<"    :    "<<dist[i]<<endl;
					}
				}
			}
			return;
		}
};

int main(){
	int n, e;
	do{
		cout << "\nEnter number of nodes: ";
		cin >> n;
		if(n<=0){
			cout << "\nError: Invalid Input.\
Number of nodes must be more than 0.\
Try Again.\n";
		}
	}while(n<=0);
	
	do{
		cout << "Enter number of edges: ";
		cin >> e;
		if(e<0){
			cout << "\nError: Invalid Input.\
Number of edges must not be negative.\
Try Again.\n";
		}
	}while(e<0);
	
	if(n==1 && e>0){
		cout << "\nError: As there is only one node in the graph,\n\
Number of edges cannot be more than 0.\n\nPROGRAM EXIT...";
	}else{
		Graph G1(n,e);
		G1.input();
		G1.minimum_distance();
	}
	return 0;
}

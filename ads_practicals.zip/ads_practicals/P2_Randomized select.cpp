#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

void exchange(int &i, int &j){
	int temp = i;
	i = j;
	j = temp;
	return;
}

int partition(int arr[],int s,int e){
	int random = s + (rand()%(e-s+1)); //generate random number between s and e
	exchange(arr[e],arr[random]);
	
	int i = s-1;
	for(int j = s; j<e; j++){
		if(arr[j] < arr[e]){
			i++;
			exchange(arr[j],arr[i]);
		}
	}
	i++;
	exchange(arr[i],arr[e]);
	
	return i;
}

int Random_select(int arr[],int s,int e,int i){
	if(s==e){
		return arr[s];
	}
	
	int p = partition(arr,s,e);
	int k = p-s+1;
	
	if(k==i){
		return arr[p];
	}else if(i<k){
		return Random_select(arr,s,p-1,i);
	}else{
		return Random_select(arr,p+1,e,i-k);
	}
}

//takes input in the array
void input(int arr[],int size){
	cout<<"Enter the element of array : \n";
	for(int i = 0; i<size; i++){
		cin>>arr[i];
	}
}

//prints the array
void print(int arr[],int size){
	for(int i = 0 ;i<size ; i++){
		cout<<arr[i]<<" ";
	}
	cout<<endl;
}

int main(){
	srand(time(0));
	cout<<"Randomized select"<<endl;
	int size;
	do{
		cout<<"Enter the size of array : ";
		cin>>size;
		if(size < 1){
			cout<<"\nError : size can't be less than 1\n";
		}
	}while(size < 1);
	
	int *arr  = new int[size];
	
	input(arr,size);
	
	cout<<"Array before searching\n";
	print(arr,size);
	int r;
	do{
		cout<<"\nEnter the rank of element : ";
		cin>>r;
		if(r<1 || r>size){
			cout<<"\nError : rank can't be <1 or >size\n";
		}
	}while(r<1 || r>size);
	
	cout<<"Element of rank "<<r<<" : "<<Random_select(arr,0,size-1,r)<<endl<<endl;
	cout<<"Array after searching\n";
	print(arr,size);
	delete[] arr;
	return 0;
}

#include <iostream>
using namespace std;

// Partition function for quicksort
int partition(int* arr, int p, int r) {
    int pivot = arr[r]; // taking the last element as pivot
    int i = p - 1;
    for (int j = p; j < r; j++) { // starting j from beginning, and i one behind j
        if (arr[j] < pivot) {
            i++;
            swap(arr[i], arr[j]);
        }
    }
    i++;
    swap(arr[i], arr[r]);
    return i;
}

// Quicksort function
void quick_sort(int* arr, int p, int r) {
    if (p < r) {
        int q = partition(arr, p, r);
        quick_sort(arr, p, q - 1);
        quick_sort(arr, q + 1, r);
    }
}

// Input function
int* input(int& size) {
    cout << "\nTAKING INPUT IN AN ARRAY:-\n";
	do{
		cout << "\nEnter size of the array: ";
		cin >> size;
	
		if(size < 1){
			cout << "\nRetry, Size must be more than 0 "<< endl;
		}
		
	}while (size <1);
    
    int* arr = new int[size];
    cout << "\nEnter elements at index:-\n";
    for (int i = 0; i < size; i++) {
        cout << "array[" << i << "]: ";
        cin >> arr[i];
    }
    return arr;
}

// Display function
void display(int* arr, int size) {
    cout << "Array: {";
    for (int i = 0; i < size; i++) {
        if (i != size - 1) {
            cout << arr[i] << ",";
        } else {
            cout << arr[i] << "}";
        }
    }
    cout << endl;
    return;
}

// Main function
int main() {
    int size;
    int* arr = input(size);
    
    cout << "\nArray before sorting:-\n";
    display(arr, size);
    
    quick_sort(arr, 0, size - 1);
    cout << "\nArray After sorting:-\n";
    display(arr, size);
    
    delete[] arr; // Free dynamically allocated memory
    return 0;
}


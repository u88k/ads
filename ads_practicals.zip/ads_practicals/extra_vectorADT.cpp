#include <iostream>
using namespace std;

class vectorADT {
private:
    int *arr;
    int size;
    int till;

public:
    // constructors
    vectorADT(int s) {
        size = s;
        arr = new int[size];
        till = -1;
    }

    vectorADT() {
        till = -1;
        size = 0;
    }

    int Size() {
        return till + 1;
    }

    int capacity() {
        return size;
    }

    int at(int index) {
        if (index > till || index < 0) {
            return -999; // Index out of bounds
        } else {
            return arr[index];
        }
    }

    bool isFull() {
        if (till == size - 1) { // Correct condition to check full
            return true;
        } else {
            return false;
        }
    }

    bool isEmpty() {
        if (till == -1) {
            return true;
        } else {
            return false;
        }
    }

    void extend(int current_size) {
        int *temp_arr = new int[current_size * 2];
        size = current_size * 2;
        for (int i = 0; i <= till; i++) { // Copy till the current size
            temp_arr[i] = arr[i];
        }
        delete[] arr;
        arr = temp_arr;
    }

    void push_front(int ele) {
        if (!isFull()) {
            int i = till + 1;
            while (i > 0) {
                arr[i] = arr[i - 1];
                i--;
            }
            arr[0] = ele;
            till++;
            cout << "\nElement Inserted.\n";
        } else {
            extend(size);
            push_front(ele);
        }
    }

    void push_back(int ele) {
        if (!isFull()) {
            arr[till + 1] = ele;
            till++;
            cout << "\nElement Inserted.\n";
        } else {
            extend(size);
            push_back(ele);
        }
    }

    void insert(int ele, int index) {
        if (!isFull()) {
            if (index <= till && index >= 0) { // Shifting required
                int i = till + 1;
                while (i > index) {
                    arr[i] = arr[i - 1];
                    i--;
                }
                arr[index] = ele;
                till++;
                cout << "\nElement Inserted." << endl;
            } else {
                if (index < size && index >= 0) {
                    cout << "\nCan't leave empty spaces in a vector,\n"
                            "Elements must be continuously allocated,\n"
                            "Try Again.\n";
                } else {
                    cout << "Index out of bounds\n";
                }
            }
        } else {
            extend(size);
            insert(ele, index);
        }
    }

    void pop_back() {
        if (isEmpty()) {
            cout << "\nNo Element present in the vector\n";
        } else {
            till--;
            cout << "\nElement deleted from the end of the vector.\n";
        }
    }

    void pop_front() {
        if (isEmpty()) {
            cout << "\nNo Element present in the vector\n";
        } else {
            for (int i = 0; i < till; i++) {
                arr[i] = arr[i + 1];
            }
            till--;
            cout << "\nElement deleted from the beginning of the vector.\n";
        }
    }

    void erase(int index) {
        if (index > till || index < 0) {
            cout << "\nIndex out of bounds\n";
        } else if (isEmpty()) {
            cout << "\nNo Element present in the vector\n";
        } else {
            for (int i = index; i < till; i++) {
                arr[i] = arr[i + 1];
            }
            till--;
            cout << "\nElement Deleted.\n";
        }
    }

    int find(int ele) {
        int i = 0;
        while (i <= till) {
            if (arr[i] == ele) {
                return i; // return index
            }
            i++;
        }
        return -999; // Element not found
    }

    ~vectorADT() {
        delete[] arr;
    }

    void display() {
        if (isEmpty()) {
            cout << "\nVector is empty.\n";
            return;
        }
        cout << "\nCurrent Vector: {";
        for (int i = 0; i <= till; i++) {
            if (i != till) {
                cout << arr[i] << ",";
            } else {
                cout << arr[i] << "}\n";
            }
        }
    }
};

void print_menu() {
    cout << "\n=================MENU================\n"
         << "0. Exit\n"
         << "1. Check capacity of the vector\n"
         << "2. Check number of elements present in the vector\n"
         << "3. Display Vector\n"
         << "4. Insert element at a particular index in the vector\n"
         << "5. Insert element at the end\n"
         << "6. Insert element at the beginning\n"
         << "7. Erase element from a particular index\n"
         << "8. Erase element from the beginning\n"
         << "9. Erase element from the end\n"
         << "10. Check element at a particular index\n"
         << "11. Resize (Extend the size of) the vector\n"
         << "12. Find element index\n"
         << "13. Check if vector is full\n"
         << "14. Check if vector is Empty\n";
}

int main() {
    int choice;
    int s;
    do {
        cout << "Enter capacity of the vector: ";
        cin >> s;

        if (s <= 0) {
            cout << "\nInvalid Input. Size can't be less than or equal to 0. Try again.\n";
        }
    } while (s <= 0);

    vectorADT v1(s);

    do {
        print_menu();
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 0:
                continue;
            case 1:
                cout << "Capacity of the vector is: " << v1.capacity() << endl;
                break;
            case 2:
                cout << "Number of elements present in the vector are: " << v1.Size() << endl;
                break;
            case 3:
                v1.display();
                break;
            case 4: {
                int ele, index;
                cout << "Enter the element: ";
                cin >> ele;
                cout << "Enter the index where you want to enter this element: ";
                cin >> index;
                v1.insert(ele, index);
                break;
            }
            case 5: {
                int ele;
                cout << "Enter the element: ";
                cin >> ele;
                v1.push_back(ele);
                break;
            }
            case 6: {
                int ele;
                cout << "Enter the element: ";
                cin >> ele;
                v1.push_front(ele);
                break;
            }
            case 7: {
                int index;
                cout << "Enter index to erase element from the vector: ";
                cin >> index;
                v1.erase(index);
                break;
            }
            case 8:
                v1.pop_front();
                break;
            case 9:
                v1.pop_back();
                break;
            case 10: {
                int index;
                cout << "Enter index to check the element present at that position in the vector: ";
                cin >> index;
                int x = v1.at(index);
                if (x != -999) {
                    cout << "Element present at the given index is: " << x << endl;
                } else {
                    cout << "Index out of bounds error. Try again.\n";
                }
                break;
            }
            case 11:
                v1.extend(v1.Size());
                cout << "Vector resized.\n";
                break;
            case 12: {
                int ele;
                cout << "Enter element to find its index: ";
                cin >> ele;
                int x = v1.find(ele);
                if (x != -999) {
                    cout << "The given element is present at index " << x << " of the vector.\n";
                } else {
                    cout << "Element not found in the vector.\n";
                }
                break;
            }
            case 13:
                if (v1.isFull()) {
                    cout << "Vector is Full.\n";
                } else {
                    cout << "Vector is not Full.\n";
                }
                break;
            case 14:
                if (v1.isEmpty()) {
                    cout << "Vector is Empty.\n";
                } else {
                    cout << "Vector is not Empty.\n";
                }
                break;
            default:
                cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 0);
    return 0;
}

